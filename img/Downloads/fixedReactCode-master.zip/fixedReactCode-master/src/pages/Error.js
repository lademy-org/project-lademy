import React from 'react'

export default function Error() {
    return (
        <div>
            hello from error page
        </div>
    )
}
 